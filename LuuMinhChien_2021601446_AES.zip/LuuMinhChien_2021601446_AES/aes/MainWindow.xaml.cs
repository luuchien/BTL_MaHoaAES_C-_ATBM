﻿using Microsoft.Office.Interop.Word;
using Microsoft.Win32;
using System.IO;
using System.Reflection.Metadata;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;



namespace aes
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        static byte[] Encrypt(string plainText, string password)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Encoding.UTF8.GetBytes(password);
                aesAlg.IV = new byte[16];
                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
                byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
                return encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
            }

        }
        static string Decrypt(byte[] cipherText, string password)
        {
            using (Aes aesAlg = Aes.Create())
            {
                aesAlg.Key = Encoding.UTF8.GetBytes(password);
                aesAlg.IV = new byte[16];
                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
                byte[] decryptedBytes = decryptor.TransformFinalBlock(cipherText, 0, cipherText.Length);
                return Encoding.UTF8.GetString(decryptedBytes);
            }
        }
        private string GenerateRandomHexPassword(int length)
        {
            const string hexChars = "0123456789abcdef";
            char[] password = new char[length];
            using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
            {
                byte[] randomBytes = new byte[length];
                rng.GetBytes(randomBytes);
                for (int i = 0; i < length; i++)
                {
                    password[i] = hexChars[randomBytes[i] % hexChars.Length];
                }
            }
            return new string(password);
        }


        private void SaveToFile(string filePath, string content)
        {
            try
            {
                // Ghi nội dung vào file
                System.IO.File.WriteAllText(filePath, content);

                MessageBox.Show("Đã lưu thành công vào file " + filePath, "Thông báo", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi lưu file: " + ex.Message, "Lỗi", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
      

        private void btnMaHoa_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string plainText = txtBanRo1.Text;
                string password = GenerateRandomHexPassword(16);
                txtpsd.Text = password;

                if (string.IsNullOrWhiteSpace(plainText) || string.IsNullOrWhiteSpace(password))
                {
                    MessageBox.Show("Vui long nhap vao ban ro !", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                byte[] encrypted = Encrypt(plainText, password);
                // string decrypted = Decrypt(encrypted, password);

                txtBanMa1.Text = Convert.ToBase64String(encrypted);
                //DecryptedTextBox.Text = decrypted;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnChuyen_Click(object sender, RoutedEventArgs e)
        {
            txtBanMa2.Text = txtBanMa1.Text;
        }

        private void btnGiaiMa_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string plainText = txtBanRo1.Text;
                string password = txtpsd.Text;
                txtpsd.Text = password;
                byte[] encrypted = Encrypt(plainText, password);
                string decrypted = Decrypt(encrypted, password);
                txtBanRo2.Text = decrypted;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void btnLuu_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Tạo một đối tượng SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Thiết lập các thuộc tính của SaveFileDialog
                saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                saveFileDialog.FilterIndex = 1; // Chỉ hiển thị tập tin .txt mặc định
                saveFileDialog.RestoreDirectory = true;

                // Hiển thị hộp thoại SaveFileDialog và kiểm tra kết quả
                if (saveFileDialog.ShowDialog() == true)
                {
                    // Lấy đường dẫn và tên file từ SaveFileDialog
                    string filePath = saveFileDialog.FileName;

                    // Lưu kết quả vào file txt
                    string content = $"Bản mã: {txtBanMa1.Text}\nBản rõ: {txtBanRo1.Text}\nKhóa tự sinh: {txtpsd.Text}";
                    SaveToFile(filePath, content);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void btnFile1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Mở hộp thoại chọn tệp
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Word files (*.docx, *.doc)|*.docx;*.doc|All files (*.*)|*.*";
                if (openFileDialog.ShowDialog() == true)
                {
                    // Đọc nội dung từ tệp tin Word
                    string wordFilePath = openFileDialog.FileName;
                    string wordContent = ReadWordFile(wordFilePath);

                    // Giải mã nội dung và hiển thị
                    string password = txtpsd.Text;
                    byte[] encryptedBytes = Convert.FromBase64String(wordContent);
                    string decryptedContent = Decrypt(encryptedBytes, password);
                    txtBanRo1.Text = decryptedContent;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string ReadWordFile(string filePath)
        {
            Microsoft.Office.Interop.Word.Application wordApp = new Microsoft.Office.Interop.Word.Application();
            Microsoft.Office.Interop.Word.Document wordDoc = wordApp.Documents.Open(filePath);
            string content = wordDoc.Content.Text;
            wordDoc.Close();
            wordApp.Quit();
            return content;
        }

        private void btnLuu2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Tạo một đối tượng SaveFileDialog
                SaveFileDialog saveFileDialog = new SaveFileDialog();

                // Thiết lập các thuộc tính của SaveFileDialog
                saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                saveFileDialog.FilterIndex = 1; // Chỉ hiển thị tập tin .txt mặc định
                saveFileDialog.RestoreDirectory = true;

                // Hiển thị hộp thoại SaveFileDialog và kiểm tra kết quả
                if (saveFileDialog.ShowDialog() == true)
                {
                    // Lấy đường dẫn và tên file từ SaveFileDialog
                    string filePath = saveFileDialog.FileName;

                    // Lưu kết quả vào file txt
                    string content = $"Bản mã: {txtBanMa2.Text}\nBản rõ: {txtBanRo2.Text}\nKhóa tự sinh: {txtpsd.Text}";
                    SaveToFile(filePath, content);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

}

